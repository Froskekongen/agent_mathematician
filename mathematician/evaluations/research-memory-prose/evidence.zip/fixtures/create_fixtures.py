"""Create the two trial fixtures once, using only the frozen memory CLI."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
CLI = ROOT.parent / "baseline-skills/research-mathematics/scripts/research_memory.py"
EVIDENCE = ROOT / "evidence"


S7 = r"""# Why even closeness preserves continuity

The issue in passing continuity to a limit is choosing one approximating
function that works at two nearby points. Pointwise convergence alone lets
that choice depend on the point. Even closeness supplies one choice for the
whole domain, so continuity of that approximating function can bridge the
two points.

## A tail estimate that works everywhere

**Research key:** `uniform-tail-estimate`

Let X be a subset of the real line and let f_n: X -> R converge to f by
even closeness: for every eta > 0 there is an integer N such that
|f_n(x) - f(x)| < eta for every n >= N and every x in X. We call this
single-index tail control. In particular, for a chosen tolerance epsilon > 0,
one index N gives |f_N(x) - f(x)| < epsilon/3 at every x in X. The same N
therefore controls both the value at a fixed x_0 and values at all nearby x.

## Continuity survives the limit

**Research key:** `uniform-limit-continuity`

Status: checked.

If every f_n is continuous on X in its relative topology and the sequence
converges to f by even closeness on X, then f is continuous on X.

To prove this, fix x_0 in X and epsilon > 0. Choose N by the tail estimate
above. Continuity of f_N at x_0 provides delta > 0 such that, whenever
x in X and |x - x_0| < delta, we have
|f_N(x) - f_N(x_0)| < epsilon/3. The triangle inequality then gives

    |f(x) - f(x_0)|
      <= |f(x) - f_N(x)| + |f_N(x) - f_N(x_0)| + |f_N(x_0) - f(x_0)|
      < epsilon/3 + epsilon/3 + epsilon/3 = epsilon.

This proves continuity at the arbitrary point x_0. No compactness of X is
needed. The argument proves continuity of the limit, not a common modulus
of continuity for all approximants. The index N depends on epsilon, and
delta may depend on epsilon, x_0, and that index.

For comparison, the continuous functions x^n on [0,1] converge pointwise
to 0 at x < 1 and to 1 at x = 1. That limit is discontinuous at 1.
Thus convergence at each point separately does not supply the shared
tail estimate used by this proof.
"""

HISTORY = r"""# A geometric approximation with a uniform tail

## The limit and its error

**Research key:** `geometric-series-tail`

For x in [0,1], define p_n(x) = sum_{k=0}^n (x/2)^k. The finite geometric
sum identity gives

    p_n(x) = (1 - (x/2)^(n+1)) / (1 - x/2).

Since 1 - x/2 >= 1/2, the functions converge to p(x) = 1/(1 - x/2), with

    |p(x) - p_n(x)| = (x/2)^(n+1)/(1 - x/2) <= 2^(-n).

The bound is independent of x, so the convergence is uniform on [0,1].
The limit is continuous because its denominator never vanishes there.
These conclusions use the geometric identity; they make no claim about
rates of convergence for oscillatory integrals.
"""


def run(name, command, canonical, changeset=None):
    arguments = [sys.executable, str(CLI), command, str(canonical)]
    result = subprocess.run(
        arguments,
        input=None if changeset is None else json.dumps(changeset),
        text=True,
        capture_output=True,
        check=True,
    )
    output = json.loads(result.stdout)
    (EVIDENCE / f"{name}-{command}.json").write_text(result.stdout)
    return output


def create(name, text, cards, links):
    directory = ROOT / name
    directory.mkdir()
    canonical = directory / "note.md"
    canonical.write_text(text)
    ensured = run(name, "ensure", canonical)
    locator = ensured["locator_to_add"]
    assert locator
    canonical.write_text(f"---\n{locator}\n---\n\n" + text)
    changeset = {
        "round_id": f"fixture-{name}",
        "expected_revision": ensured["database_revision"],
        "expected_canonical_sha256": hashlib.sha256(canonical.read_bytes()).hexdigest(),
        "cards": [{"op": "add", "card": card} for card in cards],
        "key_links": links,
    }
    (EVIDENCE / f"{name}-changeset.json").write_text(json.dumps(changeset, indent=2) + "\n")
    run(name, "apply", canonical, changeset)
    checked = run(name, "check", canonical)
    assert checked["current"] is True, checked
    return {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(directory.iterdir())
    }


EVIDENCE.mkdir(parents=True, exist_ok=True)
manifest = create(
    "s7",
    S7,
    [{
        "slug": "uniform-tail-proof-pattern",
        "kind": "proof-pattern",
        "title": "Transfer local estimates through an even closeness bound",
        "summary_md": "Reuse a globally controlled approximation to transfer a local comparison to its limit: spend the error budget on two approximation errors and one comparison inside a fixed approximant.",
        "detail_md": "The pattern only needs the triangle inequality in the target metric: d(f(x),f(y)) <= d(f(x),g(x)) + d(g(x),g(y)) + d(g(y),f(y)). Choose g so both outer errors obey one bound, then obtain the middle bound from the property of g. Beyond continuity proofs, the same decomposition combines a certified surrogate error with a local variation estimate. Budgets need not be equal: if each outer error is at most a and the middle error at most b, the resulting bound is 2a+b. Point samples of an approximation error do not certify a bound on the full domain, and vector-space operations in the target are unnecessary.",
        "disposition": "active",
        "claim_status": "proved",
        "next_test": "On reuse, identify the target metric, the domain of the approximation bound, and the source of the middle comparison.",
        "facets": [
            {"type": "field", "value": "analysis"},
            {"type": "term", "value": "even closeness"},
            {"type": "term", "value": "triangle inequality"},
        ],
    }],
    [{
        "op": "add",
        "card_slug": "uniform-tail-proof-pattern",
        "canonical_key": "uniform-tail-estimate",
        "relation": "elaborates",
        "note_md": "The even closeness estimate supplies the two outer errors in the reusable metric comparison.",
    }],
)
manifest.update(create(
    "history",
    HISTORY,
    [{
        "slug": "uniform-tail-proof-pattern",
        "kind": "proof-route",
        "title": "A uniform tail route for oscillatory integrals",
        "summary_md": "Earlier work tried to show that I_n(x) = integral_0^1 cos(n t^2)/(1+x t) dt approaches zero uniformly for x in [0,1], then use that tail estimate to transfer continuity.",
        "detail_md": "Here n is a positive integer. The proposed quantitative step was sup_{x in [0,1]} |I_n(x)| <= C/sqrt(n) for one constant C independent of x and n. The working argument handled cancellation away from t=0 but left the small-t contribution and the choice of a cutoff uniform in x unfinished. Samples at finitely many x and n up to 200 suggested decay; they did not bound the supremum or establish an asymptotic rate. No complete analytic or certified bound was retained. This route concerns the parameterized oscillatory integral, not the geometric-series calculation in the canonical account.",
        "disposition": "parked",
        "claim_status": "unresolved",
        "reason": "Work moved to the geometric example after the stationary-point estimate remained unfinished.",
        "revival_condition": "Revisit when a bound for the near-zero contribution can be combined with the away-from-zero cancellation estimate using one cutoff and constant valid for every x in [0,1] and positive integer n, or when certified evidence rules out that proposed rate.",
        "facets": [
            {"type": "field", "value": "analysis"},
            {"type": "term", "value": "uniform convergence"},
            {"type": "term", "value": "oscillatory integral"},
        ],
    }, {
        "slug": "alternating-series-remainder",
        "kind": "estimate",
        "title": "Alternating series error control",
        "summary_md": "For alternating real terms whose magnitudes decrease to zero, the truncation error is at most the first omitted magnitude.",
        "detail_md": "Reuse when a scalar alternating series has a verified monotone magnitude sequence. Without monotonicity, the first omitted term is not a certified error bound. This estimate was retained from a separate summation example and was not used in the oscillatory-integral route.",
        "disposition": "integrated",
        "claim_status": "proved",
        "facets": [
            {"type": "field", "value": "analysis"},
            {"type": "term", "value": "alternating series"},
        ],
    }],
    [],
))
(EVIDENCE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest, indent=2))
