"""Independently check the retained paired-trial states with the frozen CLI."""
from pathlib import Path
import json
import sqlite3
import subprocess
import sys

root = Path(__file__).resolve().parent
script_dir = root / "baseline-skills/research-mathematics/scripts"
sys.path.insert(0, str(script_dir))
from canonical_sections import scan_canonical

runs = json.loads((root / "prompts.json").read_text())
results = {}
for name, spec in runs.items():
    run = root / "runs" / name
    if spec["case"] == "history":
        same = {file: (run / "work" / file).read_bytes() ==
                (root / "fixtures/history" / file).read_bytes()
                for file in ("note.md", "note.research.sqlite")}
        assert all(same.values()), (name, same)
        results[name] = {"source_files_unchanged": same}
        continue
    stages = {}
    for stage in ("base", "followup"):
        canonical = run / "evidence" / stage / "note.md"
        doc = scan_canonical(canonical)
        check_path = canonical.parent / "independent-check.json"
        completed = subprocess.run([sys.executable, "-B", str(script_dir / "research_memory.py"),
                                    "check", str(canonical)], capture_output=True, text=True)
        check = json.loads(completed.stdout or completed.stderr)
        check_path.write_text(json.dumps(check, indent=2) + "\n")
        assert check["current"] and check["integrity_ok"], (name, stage, check)
        keys = sorted(doc.by_key)
        if spec["case"] == "s7":
            assert keys == ["uniform-limit-continuity", "uniform-tail-estimate"], keys
        else:
            assert "prime-valuation-obstruction" in keys, keys
        with sqlite3.connect(doc.memory_path.as_uri() + "?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            cards = [dict(row) for row in db.execute("SELECT slug, title, summary_md, disposition, claim_status FROM card ORDER BY slug")]
            facets = [dict(row) for row in db.execute("SELECT card_slug, type, value FROM card_facet ORDER BY card_slug, type, value")]
            if spec["case"] == "s7":
                assert any(f["card_slug"] == "uniform-tail-proof-pattern" and f["type"] == "term" and f["value"] == "uniform convergence" for f in facets)
                assert not any(f["type"] in ("term", "symbol") and "even closeness" in f["value"].lower() for f in facets)
        stages[stage] = {"current": True, "revision": check["database_revision"],
                         "keys": keys, "cards": cards, "facets": facets}
    assert stages["base"]["keys"] == stages["followup"]["keys"], name
    results[name] = stages
(root / "mechanical-results.json").write_text(json.dumps(results, indent=2) + "\n")
print("All retained states are current; keys stable; S7 facets synchronized; history pairs unchanged.")
