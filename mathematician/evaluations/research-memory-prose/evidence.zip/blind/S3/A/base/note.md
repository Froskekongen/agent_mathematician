---
research_memory: ./note.research.sqlite
---

# Why square roots of nonsquare integers are irrational

Squaring doubles every prime exponent. That makes the claim plausible: an integer with an odd prime exponent cannot become a square merely by multiplying it by a denominator squared. Two other useful routes locate the same rigidity in coprime denominators and in the impossibility of endlessly decreasing a positive integer.

The exact claim is: **if \(n\) is a nonnegative integer that is not the square of an integer, then its nonnegative real square root \(\sqrt n\) is irrational.** Equivalently, for \(n\in\mathbb Z_{\ge0}\), rationality of \(\sqrt n\) forces \(n\) to be a square. A nonsquare under these hypotheses is positive. Negative integers fall outside this real-square-root statement; \(0\), \(1\), and \(4\) are square boundary cases with rational roots.

The comparison below develops three elementary candidate arguments. The arithmetic steps are checked locally here; this is a strategy exploration, with an independent proof review still to perform before treating the handoff as certified. No computation or external source search was needed.

## Prime-valuation obstruction

**Research key:** `prime-valuation-obstruction`

For a prime \(p\) and positive integer \(m\), write \(v_p(m)\) for the exponent of \(p\) in the prime factorization of \(m\). Unique factorization supplies two facts: \(v_p(xy)=v_p(x)+v_p(y)\), and a positive integer is a square exactly when all its prime exponents are even. For the converse of the latter fact, halve the finitely many even exponents and multiply the corresponding prime powers.

Assume \(\sqrt n=a/b\) with positive integers \(a,b\). Squaring gives \(a^2=nb^2\). Because \(n\) is nonsquare, choose a prime \(p\) with odd \(v_p(n)\). Then

\[
2v_p(a)=v_p(n)+2v_p(b).
\]

The left side is even and the right side is odd. This is the retained obstruction: **multiplication by a square cannot change the parity of a prime exponent.** The fraction need not be in lowest terms.

The lemma spine is: unique factorization gives an odd exponent for a nonsquare; clearing a rational denominator gives an equality of integers; additivity of that exponent gives an impossible parity equation. The only substantive imported theorem is unique factorization, including its usual existence and uniqueness assertions for positive integers.

For a revealing check, \(12=2^2\cdot3\) requires the prime \(3\), yielding \(2v_3(a)=1+2v_3(b)\). Choosing \(2\) gives no parity contradiction. For \(18=2\cdot3^2\), the useful prime is instead \(2\). Thus the tempting shortcut “choose any prime divisor of \(n\)” fails: its exponent must be odd. At the square boundary \(n=36=2^2 3^2\), no prime offers the obstruction, as expected from \(\sqrt{36}=6\).

The crux is the odd-exponent characterization, not a search for a special denominator. The next step is to state that characterization explicitly, check the positivity requirements for each valuation, and write the parity contradiction as a short standalone proof.

## Coprime denominators and Bézout's identity

**Research key:** `coprime-denominator-integrality`

A different entry point is the stronger statement: **a rational number whose square is an integer is itself an integer.** Write a nonnegative rational root as \(a/b\), where \(a\ge0\), \(b>0\), and \(\gcd(a,b)=1\). The equation \(a^2=nb^2\) shows that \(b\mid a^2\).

Bézout's identity gives integers \(u,v\) with \(ua+vb=1\). Squaring this equation yields

\[
1=u^2a^2+2uvab+v^2b^2.
\]

Every term on the right is divisible by \(b\), so \(b\mid1\), and positivity gives \(b=1\). Consequently \(n=a^2\), contradicting nonsquareness.

The lemma spine is: reduce the rational fraction; use Bézout to show that a number coprime to \(a\) cannot be a nontrivial divisor of \(a^2\); conclude that the denominator is one. This route imports reduced fractions and Bézout's identity, which can be established by the Euclidean algorithm without full prime factorization. It fits the problem because integrality of a square would have to erase every denominator factor.

The cheap boundary test is \(3/2\): it is reduced, yet its denominator does not divide its numerator squared, since \(2\nmid9\). Reduction is essential to the intermediate claim about the displayed denominator: \(6/3=2\) has integer square and denominator \(3\). For \(n=0\), the argument still works with the reduced fraction \(0/1\).

The crux is making the coprimality argument explicit rather than silently assuming that squaring preserves reduced form. The next step is to decide whether the audience already knows Bézout; if so, the displayed identity supplies the whole missing denominator lemma. The rational root theorem for the monic polynomial \(x^2-n\) packages this same integrality idea, so it is not counted as another independent strategy.

## Descent through the fractional part

**Research key:** `fractional-part-denominator-descent`

This route uses order and a least positive integer instead of divisibility. Suppose \(r=\sqrt n\) is rational, with \(n\) nonsquare. Let \(k=\lfloor r\rfloor\). Since \(r\) is not an integer, \(0<r-k<1\). Among positive integers \(b\) for which \(br\) is an integer, choose the least, and put \(a=br\).

Define

\[
b'=a-kb=b(r-k).
\]

Then \(b'\) is an integer with \(0<b'<b\). Moreover,

\[
b'r=(a-kb)r=bn-ka\in\mathbb Z,
\]

because \(r^2=n\), \(a=br\), and \(n,a,b,k\) are integers. Thus \(b'\) is a smaller positive integer with the very property used to choose \(b\), a contradiction.

The lemma spine is: rationality makes the set of integer multipliers nonempty; well-ordering selects its least member; the fractional part produces a smaller positive integer; the quadratic relation keeps its product with \(r\) integral. The imported facts are the floor property and well-ordering of the positive integers. No factorization or coprimality is required.

For \(n=2\), \(k=1\), so the proposed descent is \(b'=a-b\), with \(b'r=2b-a\). The inequalities \(1<\sqrt2<2\) verify the strict decrease under the hypothetical rational representation. This checks the transformation, not the existence of such a representation. At \(n=4\), \(r=k=2\) gives \(b'=0\), pinpointing exactly why nonsquareness is needed. For nonintegral \(n\), the term \(bn\) need not be integral, so this proof does not establish the false assertion that every nonintegral square root is irrational; \(\sqrt{9/4}=3/2\) is a counterexample.

The crux is preserving the integer-multiplier property while decreasing its positive integer witness. The next step is to check both inequalities and the identity for \(b'r\) explicitly, then present this route if avoiding number-theoretic prerequisites matters more than brevity.

## Ranked comparison and recommendation

| Rank | Strategy | Main input | Decisive step | Reason for placement |
| --- | --- | --- | --- | --- |
| 1 | Prime valuations | Unique factorization | An odd exponent cannot equal an even exponent | Shortest direct explanation of the nonsquare hypothesis; works with any rational representation. |
| 2 | Coprime denominators | Reduced fractions and Bézout | \(b\mid a^2\) and \(\gcd(a,b)=1\) force \(b=1\) | Proves a reusable integrality lemma with weaker arithmetic prerequisites, but needs a denominator lemma. |
| 3 | Fractional-part descent | Floor and well-ordering | \(b'=b(r-\lfloor r\rfloor)\) is a smaller positive integer multiplier | Avoids prime factorization entirely and explains a different mechanism, at the cost of a less immediate construction. |

Proceed with the prime-valuation route. Its next concrete deliverable is a short proof with the odd-exponent characterization stated and justified before the displayed parity equation. The remaining handoff check is an independent review of that characterization, the valuation domains, and the clearing-denominators step. There is no unresolved mathematical lemma in the locally developed argument; the outstanding work is proof presentation and independent verification. Keep the Bézout route as the preferred substitute for a reader familiar with the Euclidean algorithm, and the descent route as the alternative when factorization is unavailable.

All illustrative tests above are exact hand calculations on the stated examples or symbolic transformations. They check the proposed mechanisms and their boundaries; the general arguments, rather than a finite list of examples, carry the claim.
