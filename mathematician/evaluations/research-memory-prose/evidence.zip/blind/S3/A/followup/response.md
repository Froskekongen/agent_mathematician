Updated [note.md]([workspace]/work/note.md): the ranked table now precedes the strategy details, and prime valuations are marked **deferred**. The valuation obstruction is unchanged; the coprime-denominator route is recommended next.

The companion passed validation. Follow-up evidence was saved separately, and the base evidence remains unchanged.
