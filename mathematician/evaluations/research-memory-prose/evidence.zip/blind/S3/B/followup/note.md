---
research_memory: ./note.research.sqlite
---

# Why nonsquare integers have irrational square roots

A square has an even number of copies of each prime in its factorization. A nonsquare integer has an odd number of copies of at least one prime. Introducing a denominator cannot repair that mismatch: squaring the denominator also contributes only even numbers of prime factors. This makes prime-exponent parity the most direct explanation of the claim.

The precise claim is: **if $n\in\mathbb Z_{\ge0}$ is not a perfect square, then its nonnegative real square root $\sqrt n$ is irrational.** Here a perfect square means $k^2$ for an integer $k\ge0$. Thus the nonsquare case has $n\ge2$. Negative integers have no real square root; if complex roots are intended, none can be rational because a rational number has a nonnegative square. The cases $n=0,1,4,9$ show why the nonsquare assumption is essential.

The following ranking favors explanatory clarity and few auxiliary steps. Each route has a complete elementary argument available from the stated imports. The checks here are local mathematical checks, not an independent certification of a proof. The prime-valuation route is deferred; its mathematical ranking and obstruction are unchanged. Denominator cancellation is the current next step.

| Rank | Strategy | State | Main mechanism | Required background | Crux and next check |
|---|---|---|---|---|---|
| 1 | Prime valuations | deferred | An odd prime exponent cannot equal an even exponent | Unique prime factorization | Identify a prime occurring to odd order in $n$, then compare exponents in $a^2=nb^2$ |
| 2 | Denominator cancellation | active | A reduced rational number whose square is integral has denominator $1$ | Reduced fractions and Bézout's identity | Verify that coprimality rules out $b\mid a^2$ unless $b=1$ |
| 3 | Descent between neighboring integers | alternative | A supposed rational root gives another representation with a smaller positive denominator | Integer part and the well-ordering of positive integers | Verify positivity, strict denominator decrease, and preservation of the root |

## The prime-valuation obstruction

**Research key:** `prime-valuation-obstruction`

For a prime $p$ and a positive integer $m$, let $v_p(m)$ denote the exponent of $p$ in the unique prime factorization of $m$. Multiplication adds these exponents, so squaring doubles them. The obstruction is exactly the parity of $v_p(n)$.

The lemma spine is short. First, unique prime factorization implies that a positive integer is a square if and only if every prime exponent is even: in the reverse direction, halve all the exponents to construct its integer square root. Hence a nonsquare $n$ has a prime $p$ with $v_p(n)$ odd. Next suppose $\sqrt n=a/b$, where $a,b$ are positive integers. Clearing the denominator and taking the exponent of $p$ gives

\[
a^2=nb^2,
\qquad
2v_p(a)=v_p(n)+2v_p(b).
\]

The left side is even, and the right side is odd. This is impossible. The fraction need not be reduced, so this route has no coprimality step.

The revealing test is $n=12=2^2\cdot3$. Looking only at divisibility by $2$ misses the obstruction; choosing $p=3$ gives $2v_3(a)=1+2v_3(b)$. For $n=36=2^2\cdot3^2$, every exponent is even and the obstruction disappears, as it should because $\sqrt{36}=6$. These exact examples check the prime-selection step and its square boundary; they are not an exhaustive search.

The fragile point is choosing a prime with an **odd exponent**, rather than merely a prime divisor. Nonsquare does not mean squarefree. The best next step is to write the square-characterization lemma explicitly and have a fresh reader check this parity argument with its unique-factorization assumption visible.

## Cancellation in a reduced fraction

**Research key:** `denominator-cancellation`

This route proves a useful intermediate claim: **a rational number whose square is an integer must itself be an integer.** Write $x=a/b$ with integers $a,b$, $b>0$, and $\gcd(a,b)=1$. If $x^2=n\in\mathbb Z$, then $a^2=nb^2$, so $b\mid a^2$.

The coprimality step can be checked without assuming prime factorization. Bézout's identity supplies integers $u,v$ with $ua+vb=1$. Squaring and reducing modulo $b$ yields

\[
1=(ua+vb)^2\equiv u^2a^2\equiv0\pmod b.
\]

Therefore $b\mid1$, so $b=1$. Consequently $n=a^2$, which contradicts the nonsquare assumption. The lemma spine is reduced representation, denominator divisibility, Bézout cancellation, and integrality of the root.

A boundary test is the unreduced expression $6/3=2$: its square is an integer while its displayed denominator exceeds $1$. Thus the conclusion about the denominator requires reduction. In a reduced expression such as $3/2$, the denominator $2$ cannot divide the numerator square $9$, so the mechanism behaves as expected.

This shares elementary divisibility structure with the valuation proof but emphasizes a different reusable intermediate theorem and can use Bézout instead of unique factorization. Its next check is the cancellation lemma above. It is especially useful if later work concerns rational roots of monic integer polynomials; the same denominator argument extends to that setting.

## Descent between neighboring integers

**Research key:** `denominator-descent`

This route uses the gap between a nonsquare root and the neighboring integers. Let $s=\sqrt n$ and $q=\lfloor s\rfloor$. Because $n$ is a nonsquare and $n\ge2$,

\[
q<s<q+1,\qquad q\ge1.
\]

Suppose $s$ is rational and choose a representation $s=a/b$ with $a,b$ positive integers and $b$ as small as possible. Define integers

\[
b'=a-qb,\qquad a'=nb-qa.
\]

The lemma spine consists of three exact checks:

1. $b'=b(s-q)$, so $0<b'<b$.
2. $a'=b(s^2-qs)=bs(s-q)>0$.
3. $a'/b'=s$, by cancellation of the positive factor $b(s-q)$.

Thus $a'/b'$ is another representation of the same rational number with a smaller positive integer denominator, contradicting the choice of $b$. The descent does not require the new fraction to be reduced.

For $n=2$, the transformation becomes $(a,b)\mapsto(2b-a,a-b)$; under $a/b=\sqrt2$, the new denominator is $(\sqrt2-1)b\in(0,b)$. For the nearly failing case $n=q^2$, one has $s-q=0$, so the proposed denominator is zero and the argument stops exactly where rational square roots should be allowed.

The central difficulty is preserving both positivity and strict decrease. Once those inequalities are checked, well-ordering supplies the contradiction. The next useful step is an independent check of the three identities, especially that $a'$ and $b'$ are integers even though positivity is expressed using $s$. This is the preferred alternative when a proof without prime factorization is desired.

## What small congruence tests leave unresolved

A few familiar moduli may illuminate examples, but they do not supply a uniform replacement for the routes above. For instance, $73$ is a nonsquare integer between $8^2$ and $9^2$, yet it is congruent to $1$ modulo each of $2,3,4,8,9$. Thus checking whether $n$ is a square residue only for those five moduli misses this case. This is a precise limitation of that list, not a claim that congruences can never prove the theorem. Moreover, a proof beginning from $a^2\equiv nb^2\pmod m$ must address whether $b$ can be cancelled modulo $m$.

## Recommended next step

With the prime-valuation route deferred, develop denominator cancellation into the final proof. State the integrality lemma for a rational square, write the rational number in lowest terms, and use Bézout's identity to force its denominator to be $1$. No additional mathematical lemma is currently missing beyond the stated standard imports; a fresh proof review should check the reduced-fraction assumption and the cancellation step. Retain the unchanged odd-exponent obstruction for when the valuation route resumes, and keep descent as the alternative with a different source of contradiction.

The examples and identities above were checked directly during this exploration. No numerical search, external source consultation, or independent proof review was performed.
