---
research_memory: ./note.research.sqlite
---

# Why uniform convergence preserves continuity

If continuous functions approach a limit, why should the limit remain
continuous? The proof shows where uniform convergence enters; afterward,
we examine why its uniform-tail estimate is the decisive assumption.

## Continuity survives the limit

**Research key:** `uniform-limit-continuity`

Status: accepted.

Let $X\subseteq\mathbb{R}$ and let $f_n:X\to\mathbb{R}$ be continuous on $X$
in its relative topology, for every integer $n\geq 1$. If $f_n$ converges
uniformly to $f:X\to\mathbb{R}$ on $X$, then $f$ is continuous on $X$.

Fix $x_0\in X$ and $\varepsilon>0$. Uniform convergence supplies an index
$N$ such that $|f_N(x)-f(x)|<\varepsilon/3$ for every $x\in X$.
We will use the triangle inequality to compare $f(x)$ with $f(x_0)$
through the intermediate values $f_N(x)$ and $f_N(x_0)$. The uniform bound
controls the two approximation errors. Continuity of the now-fixed
function $f_N$ at $x_0$ provides a $\delta>0$ such that

$$
x\in X,\quad |x-x_0|<\delta
\quad\Longrightarrow\quad
|f_N(x)-f_N(x_0)|<\varepsilon/3.
$$

For every such $x$, the triangle inequality puts the three bounds together:

$$
\begin{aligned}
|f(x)-f(x_0)|
&\leq |f(x)-f_N(x)|+|f_N(x)-f_N(x_0)|+|f_N(x_0)-f(x_0)|\\
&<\varepsilon/3+\varepsilon/3+\varepsilon/3
=\varepsilon.
\end{aligned}
$$

This is continuity of $f$ at $x_0$. Since $x_0$ was arbitrary, $f$ is
continuous throughout $X$. No compactness of $X$ is needed. The index $N$
depends on $\varepsilon$, and $\delta$ may depend on $\varepsilon$, $x_0$,
and the chosen index. The conclusion is continuity of the limit; the
argument supplies no common modulus of continuity for all the approximants.

## The uniform-tail estimate

**Research key:** `uniform-tail-estimate`

The proof suggests how to compare the limit's values at two nearby points:
pass through one approximating function whose continuity we already know.
The crucial requirement is that this same function approximate the limit
at both points. Uniform convergence provides a uniform error bound before
we choose the nearby point.

For the functions above, **uniform convergence** means that, for every
$\eta>0$, there is an integer $N\geq 1$ such that

$$
|f_n(x)-f(x)|<\eta
\qquad\text{for every }n\geq N\text{ and every }x\in X.
$$

The order of these choices matters: $N$ may depend on the tolerance $\eta$,
but it works throughout $X$. We can therefore choose a single approximating
function and then move around the domain without losing the error bound.

In particular, given $\varepsilon>0$, take $\eta=\varepsilon/3$. Uniform
convergence supplies an index $N$ with

$$
|f_N(x)-f(x)|<\varepsilon/3\qquad\text{for every }x\in X.
$$

This one estimate controls the error at a fixed point $x_0$ and at every
nearby point $x$. The three-part tolerance accounts for the terms in the
triangle inequality above: two approximation errors and one change within
$f_N$.

Pointwise convergence explains why the shared index matters. In that
weaker condition, the index may also depend on $x$, so choosing an
approximant at $x_0$ gives no error bound throughout a neighborhood.
For example, the continuous functions $f_n(x)=x^n$ on $[0,1]$ converge
pointwise to $0$ for $x<1$ and to $1$ at $x=1$. The limit is discontinuous
at $1$: points below $1$ can be arbitrarily close to $1$, while their limit
values remain a distance $1$ from the value there. Thus pointwise
convergence alone cannot preserve continuity. Uniform convergence supplies
exactly the uniform-tail estimate that the proof uses.
