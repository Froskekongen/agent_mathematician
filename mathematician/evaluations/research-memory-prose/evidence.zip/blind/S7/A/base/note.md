---
research_memory: ./note.research.sqlite
---

# Why uniform convergence preserves continuity

If continuous functions approach a limit, why should the limit remain
continuous? To compare its values at two nearby points, we can pass through
one approximating function whose continuity we already know. The crucial
requirement is that this same function approximate the limit at both points.
Uniform convergence gives that shared control, even before we choose the
nearby point.

## A tail estimate that works everywhere

**Research key:** `uniform-tail-estimate`

Let $X \subseteq \mathbb{R}$ and let $f_n:X\to\mathbb{R}$ be a sequence of
functions, with $n\geq 1$. The sequence converges **uniformly** to
$f:X\to\mathbb{R}$ if, for every $\eta>0$, there is an integer $N\geq 1$ such
that

$$
|f_n(x)-f(x)|<\eta
\qquad\text{for every }n\geq N\text{ and every }x\in X.
$$

The order of these choices matters: $N$ may depend on the tolerance $\eta$,
but it works throughout $X$. We can therefore choose a single approximating
function and then move around the domain without losing the error bound.

In particular, given $\varepsilon>0$, take $\eta=\varepsilon/3$. Uniform
convergence supplies an index $N$ with

$$
|f_N(x)-f(x)|<\varepsilon/3\qquad\text{for every }x\in X.
$$

This one estimate controls the error at a fixed point $x_0$ and at every
nearby point $x$. The three-part tolerance anticipates the comparison below:
two approximation errors and one change within $f_N$.

## Continuity survives the limit

**Research key:** `uniform-limit-continuity`

Status: checked.

If every $f_n$ is continuous on $X$ in its relative topology and $f_n$
converges uniformly to $f$ on $X$, then $f$ is continuous on $X$.

Fix $x_0\in X$ and $\varepsilon>0$, and choose $N$ using the uniform-tail
estimate above. Think of the comparison as a three-step journey:
from $f(x)$ to $f_N(x)$, along the continuous function to $f_N(x_0)$,
and back to $f(x_0)$. Uniform convergence controls the first and last steps.
For the middle step, continuity of the now-fixed function $f_N$ at $x_0$
provides a $\delta>0$ such that

$$
x\in X,\quad |x-x_0|<\delta
\quad\Longrightarrow\quad
|f_N(x)-f_N(x_0)|<\varepsilon/3.
$$

For every such $x$, the triangle inequality puts the three bounds together:

$$
\begin{aligned}
|f(x)-f(x_0)|
&\leq |f(x)-f_N(x)|+|f_N(x)-f_N(x_0)|+|f_N(x_0)-f(x_0)|\\
&<\varepsilon/3+\varepsilon/3+\varepsilon/3
=\varepsilon.
\end{aligned}
$$

This is continuity of $f$ at $x_0$. Since $x_0$ was arbitrary, $f$ is
continuous throughout $X$. No compactness of $X$ is needed. The index $N$
depends on $\varepsilon$, and $\delta$ may depend on $\varepsilon$, $x_0$,
and the chosen index. The conclusion is continuity of the limit; the
argument supplies no common modulus of continuity for all the approximants.

Pointwise convergence explains why the shared index matters. In that
weaker condition, the index may also depend on $x$, so choosing an
approximant at $x_0$ gives no error bound throughout a neighborhood.
For example, the continuous functions $f_n(x)=x^n$ on $[0,1]$ converge
pointwise to $0$ for $x<1$ and to $1$ at $x=1$. The limit is discontinuous
at $1$: points below $1$ can be arbitrarily close to $1$, while their limit
values remain a distance $1$ from the value there. Thus pointwise
convergence alone cannot preserve continuity. Uniform convergence supplies
exactly the common tail estimate that the proof uses.
