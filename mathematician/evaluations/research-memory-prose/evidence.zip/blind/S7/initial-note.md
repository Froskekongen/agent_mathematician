---
research_memory: ./note.research.sqlite
---

# Why even closeness preserves continuity

The issue in passing continuity to a limit is choosing one approximating
function that works at two nearby points. Pointwise convergence alone lets
that choice depend on the point. Even closeness supplies one choice for the
whole domain, so continuity of that approximating function can bridge the
two points.

## A tail estimate that works everywhere

**Research key:** `uniform-tail-estimate`

Let X be a subset of the real line and let f_n: X -> R converge to f by
even closeness: for every eta > 0 there is an integer N such that
|f_n(x) - f(x)| < eta for every n >= N and every x in X. We call this
single-index tail control. In particular, for a chosen tolerance epsilon > 0,
one index N gives |f_N(x) - f(x)| < epsilon/3 at every x in X. The same N
therefore controls both the value at a fixed x_0 and values at all nearby x.

## Continuity survives the limit

**Research key:** `uniform-limit-continuity`

Status: checked.

If every f_n is continuous on X in its relative topology and the sequence
converges to f by even closeness on X, then f is continuous on X.

To prove this, fix x_0 in X and epsilon > 0. Choose N by the tail estimate
above. Continuity of f_N at x_0 provides delta > 0 such that, whenever
x in X and |x - x_0| < delta, we have
|f_N(x) - f_N(x_0)| < epsilon/3. The triangle inequality then gives

    |f(x) - f(x_0)|
      <= |f(x) - f_N(x)| + |f_N(x) - f_N(x_0)| + |f_N(x_0) - f(x_0)|
      < epsilon/3 + epsilon/3 + epsilon/3 = epsilon.

This proves continuity at the arbitrary point x_0. No compactness of X is
needed. The argument proves continuity of the limit, not a common modulus
of continuity for all approximants. The index N depends on epsilon, and
delta may depend on epsilon, x_0, and that index.

For comparison, the continuous functions x^n on [0,1] converge pointwise
to 0 at x < 1 and to 1 at x = 1. That limit is discontinuous at 1.
Thus convergence at each point separately does not supply the shared
tail estimate used by this proof.
