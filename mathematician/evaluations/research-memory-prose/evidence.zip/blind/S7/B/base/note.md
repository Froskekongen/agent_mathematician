---
research_memory: ./note.research.sqlite
---

# Why uniform convergence preserves continuity

How can continuity survive taking a limit of functions? To compare the limit
function at two nearby points, we can compare both values with those of one
continuous approximating function. The essential step is choosing an
approximation that is accurate at both points before deciding how close the
points must be. Uniform convergence makes that choice possible.

## A tail estimate that works everywhere

**Research key:** `uniform-tail-estimate`

Let \(X\subseteq\mathbb R\) and let \(f_n:X\to\mathbb R\). The sequence
converges to \(f:X\to\mathbb R\) by **uniform convergence** if, for every
\(\eta>0\), there is an integer \(N\) such that

\[
|f_n(x)-f(x)|<\eta
\qquad\text{for every }n\ge N\text{ and every }x\in X.
\]

The word “uniform” means that the same \(N\) works everywhere on \(X\).
It may depend on the error tolerance \(\eta\), but it does not depend on
\(x\). Picture all sufficiently late approximations lying within a band of
vertical width \(2\eta\) centered on the graph of \(f\).

For continuity, we will divide an error allowance \(\epsilon>0\) among
three comparisons. Set \(\eta=\epsilon/3\) and choose \(N\) from uniform
convergence. In particular,

\[
|f_N(x)-f(x)|<\epsilon/3\qquad\text{for every }x\in X.
\]

This one function \(f_N\) approximates \(f\) at a fixed point \(x_0\)
and at every nearby point \(x\), even though the neighborhood has not yet
been chosen.

## Continuity survives the limit

**Research key:** `uniform-limit-continuity`

Status: checked.

If every \(f_n\) is continuous on \(X\) in its relative topology and
\(f_n\) converges to \(f\) by uniform convergence on \(X\), then \(f\)
is continuous on \(X\).

Fix \(x_0\in X\) and \(\epsilon>0\). Choose \(N\) by the uniform-tail
estimate above. We now hold \(f_N\) fixed. Its continuity at \(x_0\)
provides a \(\delta>0\) such that

\[
x\in X,\quad |x-x_0|<\delta
\quad\Longrightarrow\quad
|f_N(x)-f_N(x_0)|<\epsilon/3.
\]

To travel from \(f(x)\) to \(f(x_0)\), go first to \(f_N(x)\), then to
\(f_N(x_0)\), and finally to \(f(x_0)\). Uniform convergence controls the
first and last steps; continuity of the fixed approximant controls the
middle step. The triangle inequality adds their costs:

\[
\begin{aligned}
|f(x)-f(x_0)|
&\le |f(x)-f_N(x)|
   +|f_N(x)-f_N(x_0)|
   +|f_N(x_0)-f(x_0)|\\
&<\epsilon/3+\epsilon/3+\epsilon/3=\epsilon.
\end{aligned}
\]

This proves continuity at the arbitrary point \(x_0\), hence continuity
of \(f\) on \(X\). No compactness of \(X\) is needed. The index \(N\)
depends on \(\epsilon\), while \(\delta\) may depend on \(\epsilon\),
\(x_0\), and the chosen index. The proof establishes continuity of the
limit; it does not establish a common modulus of continuity for all
approximants. If \(X\) is empty, continuity is vacuous.

The order of choices explains why pointwise convergence is insufficient.
It allows the approximation index to depend on the point, so an index
chosen at \(x_0\) need not control every \(x\) in the neighborhood
subsequently supplied by continuity. For example, the continuous functions
\(f_n(x)=x^n\) on \([0,1]\) converge pointwise to \(0\) for \(0\le x<1\)
and to \(1\) at \(x=1\). The limit is discontinuous at \(1\), since its
values to the left remain \(0\). Indeed, for each fixed \(n\ge1\), values
of \(x<1\) sufficiently close to \(1\) satisfy \(x^n>1/2\). Thus no
single index makes the approximation error less than \(1/2\) everywhere,
and the uniform-tail estimate fails.
