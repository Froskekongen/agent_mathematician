Updated [the note]([workspace]/work/note.md) with the table above the details and the valuation route marked **deferred**. The valuation argument is unchanged; inline math notation is repaired.

Saved the validated canonical pair and CLI outputs in [follow-up evidence]([workspace]/evidence/followup). Base evidence is preserved.
