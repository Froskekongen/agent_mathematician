---
research_memory: ./note.research.sqlite
---

# Proof strategies for square roots of nonsquare integers

Squaring doubles every prime exponent. A positive integer fails to be a square precisely when at least one exponent is odd, so a rational square root would have to erase an odd exponent by introducing a denominator. A denominator contributes another square, which changes prime exponents only by even amounts. This is the clearest reason the claim should hold.

The precise claim is: **if $n$ is a positive integer and $n\ne k^2$ for every integer $k$, then its nonnegative real square root $\sqrt n$ is irrational.** Equivalently, for a nonnegative integer $n$, $\sqrt n\in\mathbb Q$ exactly when $n$ is an integer square. The cases $n=0,1,4,9$ explain why nonsquareness is necessary. Negative integers have no real square root and are outside this real-valued statement; either complex square root of a negative integer is automatically outside $\mathbb Q$.

Throughout, a hypothetical rational root is written $\sqrt n=p/q$ with positive integers $p,q$, giving

\[
p^2=nq^2. \tag{1}
\]

The routes below contain candidate complete arguments. Their elementary steps are checked here, but no independent proof review or formal certification was performed in this exploration. The next outstanding check is an independent review of the selected argument, rather than an unidentified missing lemma.

## Comparison and ranking

The ranking favors a short uniform mechanism, clear use of the nonsquare hypothesis, and few opportunities for a hidden assumption.

The ranks compare mathematical merits. The previously preferred prime-valuation route is now **deferred**; the reduced-denominator argument is the recommended next active route. Deferral changes the work priority, while the valuation obstruction remains unchanged. Resume the valuation route when a valuation-based exposition is wanted.

| Rank | Strategy | Main reduction and imports | Revealing test | Crux and next step |
|---|---|---|---|---|
| 1 | Prime valuations — **deferred** | Find an odd prime exponent in $n$, then take that exponent in (1); uses unique prime factorization. | $12=2^2\cdot3$: the prime $3$, not the exponent of $2$, supplies the contradiction. | Deferred. Retain the odd-exponent obstruction; resume when a valuation-based exposition is wanted. |
| 2 | Eliminate the denominator | Reduce $p/q$; any prime divisor of $q$ also divides $p$; uses existence of prime divisors and Euclid's lemma. | $n=4$ leaves $q=1,p=2$, correctly producing no contradiction before nonsquareness is used. | Check that divisibility uses $n\in\mathbb Z$; develop this as the next active proof route. |
| 3 | Infinite descent | Use the integer part of $\sqrt n$ to construct a smaller positive denominator; uses ordering, algebra, and well-ordering. | For $n=2$, the new pair is $(2q-p,p-q)$; for $n=9$, the new denominator becomes zero. | Check positivity, strict decrease, and preservation of (1); develop this route when avoiding prime arithmetic is useful. |
| 4 | Fixed congruence tests | Compare the square residues of $p^2$ and $nq^2$, keeping coprimality in view. | Modulo $4$ settles $n=3$, but every fixed modulus admits primitive local data for some nonsquare $n$. | A fixed collection of moduli cannot be a uniform proof; revive only for selected families or an adaptive prime-power argument. |

## Prime-valuation obstruction

**Research key:** `prime-valuation-obstruction`

For a prime $\ell$ and a positive integer $a$, write $v_\ell(a)$ for the number of factors of $\ell$ in its prime factorization. The point of this notation is to isolate one prime at a time:

\[
v_\ell(ab)=v_\ell(a)+v_\ell(b),\qquad v_\ell(a^2)=2v_\ell(a).
\]

The lemma spine is:

1. By unique factorization, $n$ is a square if and only if every $v_\ell(n)$ is even: even exponents can all be halved to construct an integer square root.
2. Since $n$ is nonsquare, choose a prime $\ell$ with $v_\ell(n)$ odd.
3. Applying $v_\ell$ to (1) gives
   \[
   2v_\ell(p)=v_\ell(n)+2v_\ell(q).
   \]
   The left side is even and the right side is odd, a contradiction.

This needs no assumption that $p/q$ is reduced. Even a denominator divisible by $\ell$ adds only an even exponent, so it cannot remove the obstruction. For $n=12$, taking $\ell=3$ gives $2v_3(p)=1+2v_3(q)$. For $n=18=2\cdot3^2$, it is $\ell=2$ that works. For $n=9$, every prime exponent is even and the argument correctly has no obstructing prime.

The imported result is unique prime factorization for positive integers. Positivity keeps all valuations finite and avoids applying this argument to zero. The next decisive check is to inspect the short odd-exponent lemma and the product rule; once those are accepted, the displayed parity contradiction finishes the route.

## Reduced-denominator argument

**Research key:** `rational-square-root-denominator`

Here the intermediate statement is stronger than the target: **a rational number whose square is an integer is itself an integer.** Its sign is irrelevant to this intermediate statement; for the target we keep $p,q>0$.

Choose $p/q$ in lowest terms. If $q>1$, choose a prime $\ell\mid q$. Equation (1), with $n$ an integer, implies $\ell\mid p^2$. Euclid's lemma then implies $\ell\mid p$, contradicting $\gcd(p,q)=1$. Therefore $q=1$, so $n=p^2$, contradicting nonsquareness.

Its lemma spine is reduced fraction → prime divisor of a nontrivial denominator → shared prime factor → integer root. Unlike the valuation route, it first excludes every denominator and uses nonsquareness only in the last sentence. It needs no prime factorization of $n$, although it shares the basic prime-divisibility mechanism with the leading route.

The boundary $n=4$ permits $p=2,q=1$, as it should. Integrality of $n$ is essential: $(2/3)^2=4/9$ is a rational noninteger square, so the intermediate statement fails if “integer” is weakened to “rational.” The familiar rational-root theorem applied to the monic polynomial $X^2-n$ packages this same denominator argument; it is a reformulation, not an additional independent strategy. The next check is the application of Euclid's lemma to $\ell\mid p^2$.

## Descent through the integer part

**Research key:** `square-root-denominator-descent`

This route replaces prime arithmetic with the fact that positive integer denominators cannot decrease forever. Let $a=\lfloor\sqrt n\rfloor$. Since $n$ is nonsquare,

\[
a<\sqrt n<a+1.
\]

Among all positive integer solutions to (1), choose one with minimal $q$, assuming such solutions exist. Define integers

\[
q'=p-aq,\qquad p'=nq-ap.
\]

Using $p=\sqrt n\,q$, we obtain

\[
q'=(\sqrt n-a)q,\qquad p'=\sqrt n\,q'.
\]

Thus $0<q'<q$ and $p'>0$, while $p'^2=nq'^2$. This is a new positive integer solution with smaller denominator, contradicting minimality. The algebraic preservation can also be checked without substitution:

\[
(nq-ap)^2-n(p-aq)^2=(n-a^2)(nq^2-p^2)=0.
\]

The lemma spine is strict unit interval around the root → integer transformation preserving (1) → positive smaller denominator → well-ordering contradiction. No lowest-terms assumption is required, and using a real square root and its integer part does not assume it is irrational.

For $n=2$, $a=1$, so the transformation is $(p,q)\mapsto(2q-p,p-q)$; the interval $1<\sqrt2<2$ gives both positivity and decrease. For $n=9$, $a=3$ and $p=3q$ would give $q'=0$, showing exactly where the nonsquare hypothesis is used. These are symbolic and boundary checks, not examples of actual rational roots for nonsquares. The next check is the three-part descent obligation: integrality, $0<q'<q$, and preservation of the equation. All three are explicit above.

## What congruences can and cannot settle

**Research key:** `fixed-modulus-square-root-obstruction`

Congruences can give attractive proofs for particular families. For $n=3$, suppose $p/q$ is reduced. Squares modulo $4$ are $0,1$. If $q$ were odd, (1) would require $p^2\equiv3\pmod4$, impossible. If $q$ were even, (1) would force $p$ even too, contradicting coprimality. This is a complete candidate argument for $n=3$.

The difficulty is uniformity. Merely saying “$n$ is not a square residue modulo $M$” is insufficient for an arbitrary rational candidate unless the denominator is invertible modulo $M$, or the noninvertible case is separately eliminated. More decisively, **no one fixed modulus detects all nonsquares from (1) and coprimality alone.** For every positive integer $M$, take

\[
n=M^2+M.
\]

It is nonsquare because $M^2<n<(M+1)^2$, but the coprime pair $p=M,q=1$ satisfies $p^2\equiv nq^2\pmod M$. This is only a solution to the congruence, not to (1). A finite fixed collection of moduli has the same limitation: apply this construction to their least common multiple.

Choosing moduli adaptively from the odd prime exponents of $n$ can restore a uniform argument, but then the central mechanism is the prime-valuation obstruction already ranked first. Retain fixed congruences for teaching examples or restricted families where one modulus is known to work; do not treat failure of a few residue tests as evidence of rationality.

## Recommended next step

Use the reduced-denominator route for the next proof: take a reduced fraction, eliminate a nontrivial denominator using a prime divisor and Euclid's lemma, and conclude that the integer radicand would be a square. Have an independent reader check the divisibility step and the precise positive-integer scope. The previously preferred prime-valuation route is **deferred**; its odd-exponent obstruction and argument remain unchanged. Resume it when a valuation-based exposition is wanted. Keep descent as the substantive alternative when a proof based on ordering is desired.

The evidence here consists of the displayed elementary deductions, hand-checked examples $n=2,3,4,9,12,18$, and the explicitly proved fixed-modulus counterfamily. No numerical search, external source lookup, or machine certification was used.
