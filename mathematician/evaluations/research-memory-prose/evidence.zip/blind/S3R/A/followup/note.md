---
research_memory: ./note.research.sqlite
---

# Why square roots of nonsquare integers are irrational

Squaring doubles the multiplicity of every prime factor. A nonsquare positive integer has at least one prime with odd multiplicity, so its square root should resist every attempt to express it as a ratio of integers. This prime-valuation obstruction is the most direct explanation. Two other routes expose different reasons that a rational square root would have to be an integer.

The exact claim is: **for every integer \(n\geq0\) that is not the square of an integer, the nonnegative real number \(\sqrt n\) is irrational.** Since 0 and 1 are squares, the hypotheses imply \(n\geq2\). Negative integers are outside this real-square-root statement. Nonsquareness is essential: \(\sqrt0=0\), \(\sqrt1=1\), and \(\sqrt4=2\) are rational.

This is a comparison of proof strategies. The arguments below reach candidate complete proofs using the stated elementary imports; they have received local checks, but no independent proof review has been performed. What remains is verification of those imports and the indicated delicate steps, rather than discovery of an additional conjectural lemma.

## Ranked strategy comparison and next step

| Rank | Strategy | Why it is promising | Required input and crux | Next check |
|---|---|---|---|---|
| 1 | Prime valuation — **deferred** | An odd exponent cannot equal a difference of even exponents; no fraction reduction needed. | Unique prime factorization; choose an odd-exponent prime. | Verify the square criterion and valuation equality. |
| 2 | Eliminate the denominator | An integer square forces a rational number to be an integer; avoids factoring the particular \(n\). | Lowest terms and Bézout; cancellation requires coprimality. | Check the explicit Bézout divisibility lemma. |
| 3 | Interval descent | Builds a strictly smaller positive denominator from a nonintegral root. | Floor and well-ordering; preserve positive integer numerator and denominator. | Check the transformation and strict inequalities. |

The prime-valuation route is **deferred**. Its rank records its mathematical promise; the valuation obstruction is unchanged. The route-specific checks below describe what to verify when pursuing each route.

**Recommendation:** develop denominator elimination next, starting with the Bézout divisibility lemma. Resume the prime-valuation route when it is reactivated, and retain interval descent when a factorization-free explanation is valuable. Before treating this exposition as independently checked, verify the stated elementary imports and the exact steps identified below. No external sources or software computations were used; the examples and identities were checked directly during this exploration.

## Prime-valuation obstruction

**Research key:** `prime-valuation-obstruction`

For a prime \(p\) and positive integer \(t\), let \(v_p(t)\) be the number of factors of \(p\) in \(t\). Unique prime factorization gives
\[
v_p(st)=v_p(s)+v_p(t),\qquad v_p(t^2)=2v_p(t).
\]
It also gives the decisive witness: a positive integer is a square if and only if every exponent in its prime factorization is even. The reverse direction follows by halving each exponent and multiplying the resulting prime powers. Thus a nonsquare \(n\) has a prime \(p\) with \(v_p(n)\) odd.

Suppose \(\sqrt n=a/b\), where \(a,b\) are positive integers. Squaring and clearing the denominator gives \(a^2=nb^2\). At the witness prime,
\[
2v_p(a)=v_p(n)+2v_p(b).
\]
The left side is even and the right side is odd. This is the contradiction. The fraction need not be in lowest terms: any denominator contributes only an even exponent and cannot remove the obstruction.

The lemma spine is: establish the prime-factorization criterion for squares; select an odd exponent; clear a hypothetical rational denominator; compare parity at that prime. Its imports are existence and uniqueness of prime factorization and the elementary exponent laws above. The crux is selecting a prime of **odd exponent**, not merely a prime divisor.

For a revealing test, take \(n=12=2^2\cdot3\). The prime 2 gives no parity contradiction, but the prime 3 gives \(2v_3(a)=1+2v_3(b)\), which does. Taking \(n=18=2\cdot3^2\) reverses which prime works. At the boundary \(n=36=2^2\cdot3^2\), neither prime is an obstruction, consistently with \(\sqrt{36}=6\).

The best next step is to write out the square criterion from prime factorization, then have a fresh reader check the parity equality and positivity assumptions on the valuation arguments. This route ranks first because it explains exactly what distinguishes squares from nonsquares and needs only one witness prime.

## Eliminate the denominator

**Research key:** `rational-square-root-integrality`

A broader intermediate statement is useful: **a nonnegative rational number whose square is an integer is itself an integer.** To apply it here, put \(\sqrt n=a/b\) in lowest terms, with \(a,b>0\) and \(\gcd(a,b)=1\). The equation \(a^2=nb^2\) implies \(b\mid a^2\). Coprimality forces \(b=1\), so \(n=a^2\), contrary to the hypothesis.

The cancellation step can be supplied without importing the whole rational-root theorem. By Bézout's identity, choose integers \(u,v\) with \(ua+vb=1\). Squaring gives
\[
1=u^2a^2+b(2uav+v^2b).
\]
If \(b\mid a^2\), then \(b\mid1\); since \(b>0\), it follows that \(b=1\). This proves the exact divisibility lemma needed. The zero case in the broader intermediate statement is immediate and handled separately.

The lemma spine is: reduce the fraction; derive \(b\mid a^2\); use Bézout to eliminate the denominator; contradict nonsquareness. Its imports are a lowest-terms representation and Bézout's identity for coprime integers. Its crux is coprimality, which must precede cancellation. This argument fits because \(X^2-n\) is a monic polynomial with integer coefficients; the denominator has no leading coefficient into which it can disappear.

A cheap boundary test is \((3/2)^2=9/4\): its reduced denominator prevents its square from being an integer. Another test shows why reduction matters: \(4/2=2\) has integer square although the displayed denominator exceeds 1. The lemma concerns the denominator in a reduced representation.

The best next step is to verify the Bézout expansion and package the argument as a rational-square integrality lemma. This route ranks second: it is short, avoids factoring the particular \(n\), and is reusable for denominator arguments. The valuation route explains the nonsquare obstruction more explicitly.

## Descent between consecutive integers

**Research key:** `interval-descent`

A third route uses order and the impossibility of endlessly decreasing positive integers. Let \(x=\sqrt n\) and \(m=\lfloor x\rfloor\). Nonsquareness gives \(m<x<m+1\). Assume \(x\) is rational, and choose a representation \(x=a/b\) with positive integers \(a,b\) and the smallest possible denominator \(b\). Define
\[
b'=a-mb=b(x-m),\qquad a'=nb-ma.
\]
Both are integers. The interval gives \(0<b'<b\), and
\[
xb'=bx(x-m)=nb-ma=a'.
\]
Since \(x>0\) and \(b'>0\), also \(a'>0\). Thus \(x=a'/b'\) has a smaller positive integer denominator, contradicting minimality.

The lemma spine is: trap the nonintegral root between adjacent integers; choose a least denominator by well-ordering; construct the smaller denominator; use \(x^2=n\) to obtain an integer numerator. Its imports are the floor property of real numbers and well-ordering of positive integers. The crux is preserving integrality and strict positivity. This argument needs neither unique factorization nor coprime cancellation.

For a cheap symbolic test at \(n=2\), \(m=1\) and the construction is \((a',b')=(2b-a,a-b)\). The inequalities \(b<a<2b\) give positive numerator and denominator and a strictly smaller denominator. This checks the transformation under the hypothetical equation; it does not assert that such integers exist. At the square boundary \(n=4\), \(x=m=2\), so \(b'=0\), and the descent cannot begin.

The best next step is to verify the identity \(xb'=a'\), positivity, and the least-denominator choice as a self-contained lemma. This route ranks third because its construction takes more explanation, but becomes the first choice if the aim is a proof from order and well-ordering without factorization or Bézout.

## Limits of simpler screens

Parity alone proves the case \(n=2\) but is not universal: for odd \(n\), the equation \(a^2=nb^2\) can be consistent with both \(a\) and \(b\) odd. Nor can one fixed modulus distinguish every nonsquare integer from squares. For any integer \(M\geq1\), the nonsquare \(n=M^2+1\) lies strictly between \(M^2\) and \((M+1)^2\), yet is congruent to the square 1 modulo \(M\). With \(a\equiv b\equiv1\pmod M\), even the cleared equation has no contradiction modulo that fixed \(M\). A finite preselected collection of moduli has the same limitation by using their least common multiple. This does not rule out congruence arguments whose modulus depends on \(n\); those may recover prime-divisibility information.

These are exact algebraic checks, not a computational search. No numerical approximations or claims based on a tested range are used.

