---
research_memory: ./note.research.sqlite
---

# A geometric approximation with a uniform tail

## The limit and its error

**Research key:** `geometric-series-tail`

For x in [0,1], define p_n(x) = sum_{k=0}^n (x/2)^k. The finite geometric
sum identity gives

    p_n(x) = (1 - (x/2)^(n+1)) / (1 - x/2).

Since 1 - x/2 >= 1/2, the functions converge to p(x) = 1/(1 - x/2), with

    |p(x) - p_n(x)| = (x/2)^(n+1)/(1 - x/2) <= 2^(-n).

The bound is independent of x, so the convergence is uniform on [0,1].
The limit is continuous because its denominator never vanishes there.
These conclusions use the geometric identity; they make no claim about
rates of convergence for oscillatory integrals.
