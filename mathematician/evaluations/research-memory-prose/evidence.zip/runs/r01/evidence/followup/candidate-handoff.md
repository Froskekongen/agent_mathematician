CANDIDATE FULL PROOF — NOT CERTIFIED

This round changes table placement and pursuit order only. Exact theorem, three candidate arguments, assumptions, imports, fragile steps, and local mathematical checks remain in the unchanged strategy sections of the canonical note. The valuation route is deferred at the user's request, without changing the parity obstruction. Independent review remains outstanding. The recommended next route is now the coprime-denominator proof; review reduced form, the squared Bezout identity, and b dividing 1. No mathematical claim status is upgraded.

Marker audit: all three semantic referents and their section text are unchanged, so all three keys remain unchanged. The ranking and recommendation sections remain unindexed. The parked integer-only descent card remains accurate and its current canonical relation remains valid. No card, artifact, or relation mutation is needed; only the canonical digest and indexed positions require refresh.
