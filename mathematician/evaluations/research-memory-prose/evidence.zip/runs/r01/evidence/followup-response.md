Updated [note.md](/private/var/folders/xp/t2q951g9241cs12lt29g8sg80000gn/T/research-memory-prose-8iq4km7x/runs/r01/work/note.md): the ranked table now precedes the strategy details, and prime valuations are marked **deferred**. The valuation obstruction is unchanged; the coprime-denominator route is recommended next.

The companion passed validation. Follow-up evidence was saved separately, and the base evidence remains unchanged.
