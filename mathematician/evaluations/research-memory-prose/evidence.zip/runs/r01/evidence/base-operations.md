# Base operations

All work was confined to this run directory. No other runs, parent workspace, agents, or internet were inspected or used.

## Instruction files read

- `skills/explore-proof-strategies/SKILL.md` (full): invoked local skill.
- `skills/mathematical-integrity/SKILL.md` (full): linked shared mathematical guidance.
- `skills/research-mathematics/references/research-memory.md` (full): linked file-backed workflow.
- `skills/research-mathematics/scripts/research_memory.py` (partial implementation reference): searched card status/relation definitions and read lines 270–390 for normative card/facet validation. Also read its `apply --help` output.

No AGENTS.md was found by the run-local filename inventory. Conditional computational-checking instructions were not needed: all mechanism checks were elementary hand calculations, with no material computational experiment. Installed skills were not read.

## Canonical and memory actions

Read-before-ensure: `work/note.md` was absent. Created the mathematical draft, then ran ensure. Added its returned scalar locator. Corrected three Python string-escape artifacts in LaTeX before freezing the canonical text. Read the full final Markdown and reviewed every formula and boundary example.

Created one generated workpad under this OS-temporary run directory for the internal candidate-proof handoff, transaction, and raw CLI outputs. Its internal handoff records exact theorem, assumptions, imports, fragile steps, local checks, and outstanding independent review under `CANDIDATE FULL PROOF — NOT CERTIFIED`.

Every memory invocation used `python3 skills/research-mathematics/scripts/research_memory.py`:

| Arguments | Result | Exact saved output |
| --- | --- | --- |
| `apply --help` | Normative operation grammar read; repeated once to save identical help text. | `base/00-apply-help.txt` |
| `ensure work/note.md` | Created canonical-stem companion, revision 0; returned `research_memory: ./note.research.sqlite`. | `base/01-ensure.json` |
| `read work/note.md meta` | Revision 0; digest mismatch expected after publishing locator and text corrections. | `base/02-meta-before.json` |
| `read work/note.md keys` | Three semantic subject keys, no pagination remainder; pre-close digest mismatch visible. | `base/03-keys-before.json` |
| `apply work/note.md` with workpad `changeset.json` on stdin | One successful transaction, revision 1; one parked noncanonical formalization card and one link. | `base/04-apply.json` |
| `check work/note.md` | `ok=true`, `current=true`, `integrity_ok=true`, zero errors. | `base/05-check.json` |
| `read work/note.md key prime-valuation-obstruction` | Exact section read; current canonical digest. | `base/06-key-prime.json` |
| `read work/note.md key coprime-denominator-integrality` | Exact section read; current canonical digest. | `base/07-key-denominator.json` |
| `read work/note.md key fractional-part-denominator-descent` | Exact section and linked card summary read; `link_current=true`. | `base/08-key-descent.json` |
| `read work/note.md card integer-only-descent-encoding --full` | Full selected card read, complete body and relation, revision 1. | `base/09-card-descent.json` |

All commands succeeded. The temporary digest mismatch was resolved by the single close transaction. No native artifacts or additional database were created. All three keys were audited for necessity, single-subject granularity, and stability; the overview and ranked table remain unindexed. The card stores an optional integer-only algebraic encoding with its revival condition, rather than duplicating the canonical proof.

## Evidence close

Copied the final canonical pair byte-for-byte to `evidence/base/note.md` and `evidence/base/note.research.sqlite`. Copied raw CLI stdout, the applied changeset, and the internal candidate handoff unchanged from the workpad. Saved the user-facing response to `evidence/base-response.md`. Deleted the sole workpad and its temporary location pointer after successful closure and evidence copying. No follow-up request was anticipated or performed.

Final canonical SHA-256: `eb3f1e7f9be243a842b244cfadd3e08672bce99b81d197797347169bbc06b4b7`.

Companion SHA-256 at evidence capture: `06415e507e046b69293fcaabf5cd6fa4bf488be17ced8666a047de4db38101ce`.
