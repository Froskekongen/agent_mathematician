CANDIDATE FULL PROOF — NOT CERTIFIED

Exact theorem: for nonnegative integer n, rationality of its nonnegative real square root implies n is an integer square. Equivalently, every positive nonsquare integer has irrational real square root.

Candidate 1: unique factorization characterizes nonsquares by an odd prime exponent; a^2 = n b^2 forces 2 v_p(a) = v_p(n) + 2 v_p(b), a parity contradiction. Assumptions: n,a,b positive integers; p prime. Imports: unique factorization and valuation additivity. Fragile steps: odd exponent selection, positivity excluding v_p(0), no assumption of a reduced fraction. Local checks: 12 at p=3, 18 at p=2, 36 has no odd exponent. Missing verification: independent challenge and proof review; no local lemma gap.

Candidate 2: reduced a/b gives gcd(a,b)=1 and b divides a^2; square a Bezout identity to conclude b divides 1; then n=a^2. Assumptions: a>=0, b>0, n integer. Imports: reduced fractions, Bezout. Fragile step: every term in the squared identity is divisible by b. Local checks: 3/2 and unreduced 6/3; n=0 uses 0/1. Missing verification: independent challenge of the denominator lemma and review; no local lemma gap.

Candidate 3: minimal positive integer b such that br is integer; k=floor r, a=br, b'=a-kb. Nonsquareness gives 0<b'<b; b'r=bn-ka is integer, contradiction. Assumptions: r positive, r^2=n an integer, r noninteger and rational under contradiction. Imports: floor and well-ordering. Fragile steps: nonempty set of multipliers, strict positivity, preservation of integral product. Local checks: n=2 transformation, n=4 zero boundary, n=9/4 shows role of integrality. Missing verification: independent review of the order inequalities and invariant; no local lemma gap.

Marker audit: each of the three keys denotes a durable mathematical mechanism, not a rank or recommendation. The claim and table remain unindexed. No key migration needed. Only reusable noncanonical material retained: an optional integer-only encoding of descent, parked until formalization is wanted. No artifacts were needed.
