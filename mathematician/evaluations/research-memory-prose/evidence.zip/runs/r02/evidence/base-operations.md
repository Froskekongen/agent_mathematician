# Base operations

Instruction files read (local copies):

- `skills/explain-mathematics/SKILL.md`
- `skills/mathematical-integrity/SKILL.md`
- `skills/research-mathematics/references/research-memory.md`

Read the existing canonical `work/note.md` before memory writes. Its declared companion is `./note.research.sqlite`; the companion exists.

No other runs, parent workspace, agents, or internet were used.

Memory commands below use the prefix `python3 skills/research-mathematics/scripts/research_memory.py` and run from this run directory. Outputs were captured verbatim in the generated OS-temporary workpad `base-workpad-03jd2k6x/`, then copied byte for byte to `evidence/base/`. Independent reads ran in parallel.

| Command arguments | Result | Captured stdout |
| --- | --- | --- |
| `ensure work/note.md` | Existing companion reused; current at database revision 1; no errors. | [output](base/ensure.json) |
| `read --help` | Read selector syntax. | [output](base/read-help.txt) |
| `apply --help` | Read changeset grammar. | [output](base/apply-help.txt) |
| `read work/note.md keys` | Two existing keys: uniform-tail-estimate and uniform-limit-continuity. | [output](base/before-keys.json) |
| `read work/note.md key uniform-tail-estimate --full` | Rejected: --full is valid only with card or artifact. No mutation; corrected below. | [output](base/invalid-full-before-key-uniform-tail-estimate.json) |
| `read work/note.md key uniform-limit-continuity --full` | Rejected: --full is valid only with card or artifact. No mutation; corrected below. | [output](base/invalid-full-before-key-uniform-limit-continuity.json) |
| `read work/note.md key uniform-tail-estimate` | Read section and linked proof-pattern summary; no artifacts. | [output](base/before-key-uniform-tail-estimate.json) |
| `read work/note.md key uniform-limit-continuity` | Read section; no linked cards or artifacts. | [output](base/before-key-uniform-limit-continuity.json) |
| `read work/note.md card uniform-tail-proof-pattern --full` | Read the complete card and its key link at revision 1. | [output](base/before-card-uniform-tail-proof-pattern.json) |
| `apply work/note.md < base-workpad-03jd2k6x/changeset.json` | One curated transaction updated one card and one key link; database revision 2; ok=true. | [output](base/apply.json) |
| `check work/note.md` | Current canonical digest, integrity_ok=true, ok=true, and zero errors. | [output](base/check.json) |
| `read work/note.md key uniform-tail-estimate` | Exactly reread changed section; updated card link is current. | [output](base/after-key-uniform-tail-estimate.json) |
| `read work/note.md key uniform-limit-continuity` | Exactly reread changed section; conclusion and pointwise supporting example retained. | [output](base/after-key-uniform-limit-continuity.json) |
| `read work/note.md card uniform-tail-proof-pattern --full` | Exactly reread changed card; title, term facet, and link note use uniform convergence; card and link revision 2. | [output](base/after-card-uniform-tail-proof-pattern.json) |

The canonical note was rewritten in place. The uniform-tail estimate and continuity conclusion retain their original keys. The pointwise-limit example remains supporting prose under the continuity subject, with no new key. The three-error proof was checked directly: uniform convergence supplies both outer bounds and continuity of a fixed approximant supplies the middle bound. Relative continuity, the quantifier order, lack of a compactness requirement, and the dependence of the choices are explicit.

After the Markdown was final, its SHA-256 digest was frozen in `base/changeset.json`. The curated transaction used expected database revision 1, card revision 1, and key-link revision 1. It preserved the proof-pattern card slug and key target, updating its title, term facet, and key-link note to standard terminology. The reusable metric comparison and its error-budget detail were retained. No artifacts needed updating.

After successful validation and exact rereads, the final pair was copied unchanged to `base/note.md` and `base/note.research.sqlite`. Their byte equality to the canonical pair and SHA-256 digests are recorded in `base/snapshot-verification.json`. The user-facing response was saved as `base-response.md`. The workpad was deleted after capture. No canonical or companion content was changed during evidence capture.
