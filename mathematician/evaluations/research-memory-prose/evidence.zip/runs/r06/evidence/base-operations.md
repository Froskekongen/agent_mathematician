# Base-run operations

All work was confined to this run directory. Only evidence files were created. No other runs, parent-workspace content, other agents, or internet sources were used.

## Instruction files read

- `skills/explain-mathematics/SKILL.md` — requested local skill; read initially and captured again with its dependencies.
- `skills/mathematical-integrity/SKILL.md` — linked shared integrity instructions.
- `skills/research-mathematics/references/research-memory.md` — linked retrieval protocol.

Their contents are captured in `evidence/base/instructions.txt`. No additional reference was needed: the computational-artifact instructions apply to retained programs, and this task only reads a known card.

## Commands and results

1. `pwd && rg --files -g 'AGENTS.md' -g 'SKILL.md' -g 'note.md' -g '*uniform-tail*' -g '*memory*'` — confirmed this run directory and found the local skills, memory CLI/reference, and `work/note.md`; no `AGENTS.md` was returned.
2. `cat skills/explain-mathematics/SKILL.md` — read the requested skill.
3. `mkdir -p evidence/base && cat skills/explain-mathematics/SKILL.md skills/mathematical-integrity/SKILL.md skills/research-mathematics/references/research-memory.md | tee evidence/base/instructions.txt` — read/captured the applicable local instructions.
4. `cat work/note.md | tee evidence/base/canonical-note.txt` — read the canonical account before memory retrieval. Its published companion is `./note.research.sqlite`; its geometric-series conclusion explicitly makes no oscillatory-integral rate claim.
5. `python3 skills/research-mathematics/scripts/research_memory.py read --help | tee evidence/base/read-help.txt` — inspected read-only selectors and flags.
6. `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md keys | tee evidence/base/keys.json` — succeeded; one key, `geometric-series-tail`; database revision 1; current canonical digest matches the indexed digest.
7. `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md card uniform-tail-proof-pattern --full | tee evidence/base/card-uniform-tail-proof-pattern.json` — succeeded; retrieved the complete detail (590 characters, no next offset). The card has disposition `parked`, claim status `unresolved`, and explicit revival conditions. No linked keys, artifacts, origins, or relation edges were returned, so no relation hop or search was needed.
8. `shasum -a 256 work/note.md work/note.research.sqlite | tee evidence/base/source-pair-before.sha256` — captured source-pair digests alongside the read-only retrieval.
9. Wrote the chat explanation to `evidence/base-response.md` and this operations record using quoted shell here-documents.
10. `shasum -a 256 work/note.md work/note.research.sqlite | tee evidence/base/source-pair-after.sha256` and `diff -u evidence/base/source-pair-before.sha256 evidence/base/source-pair-after.sha256` — verified the source pair remained unchanged; empty diff, exit status 0.

No `ensure`, `apply`, database creation, document editing, broad memory dump, or mathematical research was performed. The successful targeted reads report a matching indexed digest, but were not treated as validation of the entire pair. The explanation preserves the distinction between a parked approach and an unresolved claim, and between this historical integral and the current geometric calculation.
