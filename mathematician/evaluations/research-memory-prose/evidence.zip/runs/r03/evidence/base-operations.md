# Base operations

All work was confined to this run directory. Only evidence files were created. No internet, other run, parent workspace, or other agent was used.

## Instruction files read

1. `skills/explain-mathematics/SKILL.md` — requested local skill; read with `cat`.
2. `skills/mathematical-integrity/SKILL.md` — linked shared integrity guidance; read with `cat`.
3. `skills/research-mathematics/references/research-memory.md` — linked retrieval protocol; read with `cat`.
4. `skills/research-mathematics/references/computational-checking.md` — linked reference; read with `cat`. No computational research or artifact checking was undertaken.

Their contents are preserved in `base/instructions-read.txt`. Initial discovery used `pwd` and `rg --files -g 'AGENTS.md' -g 'SKILL.md' -g '*uniform-tail*' -g '*memory*' -g 'note.md' -g '*companion*'`; it found the local skill files, memory script/reference, and `work/note.md`, with no AGENTS.md result.

## Source read

`cat work/note.md` supplied the authoritative companion locator `./note.research.sqlite`, the key `geometric-series-tail`, and the geometric-series claim. Snapshot: `base/canonical-read.txt`.

Before retrieval: `shasum -a 256 work/note.md work/note.research.sqlite`, saved in `base/source-sha256-before.txt`.

## Memory commands and results

Commands ran from the run directory, with no `ensure`, `apply`, search, or `all` call.

1. `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md keys`
   - Exit 0; `ok: true`; one key, `geometric-series-tail`; canonical digest current.
   - Full output: `base/01-keys.json`.
2. `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md key geometric-series-tail`
   - Exit 0; `ok: true`; returned the canonical section with no linked cards or artifacts; canonical digest current.
   - Full output: `base/02-key-geometric-series-tail.json`.
3. `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md card uniform-tail-proof-pattern --full`
   - Exit 0; `ok: true`; exact known card returned in full, with no further body chunk or relation hop required; revision 1, disposition `parked`, claim status `unresolved`.
   - Recorded missing near-zero estimate and uniform cutoff, finite samples through n=200, and a revival condition requiring uniform analytic control or certified evidence against the proposed rate.
   - Full output: `base/03-card-uniform-tail-proof-pattern-full.json`.

All three memory reads reported database revision 1 and `canonical_digest_current: true`. No whole-pair `check` was run, so no stronger whole-pair integrity result is claimed.

## Evidence close

Saved the chat explanation to `base-response.md`. Wrote evidence snapshots and this operations record using Python standard-library file operations only. Repeated the source SHA-256 command after evidence creation; output is in `base/source-sha256-after.txt`. Compared before/after hashes with `cmp`; result is in `base/source-unchanged.txt`.
