# Base operations

All operations are confined to this run. No other runs, parent workspace, agents, or internet were consulted.

Instruction files read:
- `skills/explore-proof-strategies/SKILL.md` (entire file).
- `skills/mathematical-integrity/SKILL.md` (entire linked file).
- `skills/research-mathematics/references/research-memory.md` (entire linked file).

Additional local implementation inspection: `research_memory.py` card schema constants, state validation, and key-link operation grammar. `rg --files --hidden -g '!skills/**'` found no existing canonical work or local AGENTS.md. There was no existing companion to recover. Computational-checking instructions were not needed: checks use exact hand calculations and symbolic arguments, not numerical experiments.

Memory command reconnaissance:
- `python3 skills/research-mathematics/scripts/research_memory.py read --help` succeeded; inspected selectors, exact reads, and `--full`.
- `python3 skills/research-mathematics/scripts/research_memory.py apply --help` succeeded; inspected transaction grammar and example.

An initial directory-creation attempt found that empty `work/` already existed and exited before writing anything. Retried with `exist_ok=True`.

Generated temporary workpad: `workpad-base-hz_16tz9`. CLI stdout/stderr is captured there until post-close evidence copying. Final evidence retains relevant outputs verbatim.

- Read newly written `work/note.md` completely, then ran `python3 skills/research-mathematics/scripts/research_memory.py ensure work/note.md` (exit 0). Output: `evidence/base/ensure.json`; stderr: `evidence/base/ensure.stderr.txt`.

- Published returned locator `research_memory: ./note.research.sqlite` before other memory commands. Audited three subject keys; left introduction, negative-screen discussion, ranking, and recommendation unindexed. Finished the mathematical account and froze SHA-256 `3994ab323373803d300637bd6d79e13edfb6e22424a5a1872ae05048bffa591a`.
- Ran `python3 skills/research-mathematics/scripts/research_memory.py apply work/note.md < changeset.json` (exit 0) with expected revision 0 and frozen digest. One curated transaction adds the internal review handoff and its three route links. Exact request: `evidence/base/changeset.json`; output: `evidence/base/apply.json`; stderr: `evidence/base/apply.stderr.txt`.

- Ran `python3 skills/research-mathematics/scripts/research_memory.py check work/note.md` (exit 0). Exact output: `evidence/base/check.json`; stderr: `evidence/base/check.stderr.txt`.
- Initial exact read `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md key prime-valuation-obstruction --full` was rejected: `--full is valid only with read card or read artifact`. No state was changed. Preserved empty stdout and exact error under `evidence/base/read-key-full-rejected-prime-valuation-obstruction.*`; corrected below.
- Initial exact read `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md key rational-square-root-integrality --full` was rejected: `--full is valid only with read card or read artifact`. No state was changed. Preserved empty stdout and exact error under `evidence/base/read-key-full-rejected-rational-square-root-integrality.*`; corrected below.
- Initial exact read `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md key interval-descent --full` was rejected: `--full is valid only with read card or read artifact`. No state was changed. Preserved empty stdout and exact error under `evidence/base/read-key-full-rejected-interval-descent.*`; corrected below.
- Ran `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md card square-root-proof-review --full`; returned `ok: true`, revision 1, full 2,888-character body, three current key links, no pending pagination. Exact output: `evidence/base/read-card-square-root-proof-review.json`; stderr empty.
- Ran `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md key prime-valuation-obstruction` (exit 0). Exact output: `evidence/base/read-key-prime-valuation-obstruction.json`; stderr: `evidence/base/read-key-prime-valuation-obstruction.stderr.txt`.
- Ran `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md key rational-square-root-integrality` (exit 0). Exact output: `evidence/base/read-key-rational-square-root-integrality.json`; stderr: `evidence/base/read-key-rational-square-root-integrality.stderr.txt`.
- Ran `python3 skills/research-mathematics/scripts/research_memory.py read work/note.md key interval-descent` (exit 0). Exact output: `evidence/base/read-key-interval-descent.json`; stderr: `evidence/base/read-key-interval-descent.stderr.txt`.

Final results: `check` reported current revision 1, integrity true, zero errors, one card, and three card-key links. All three exact key reads returned complete section bodies and current links; the full card read was complete. No artifacts were added or changed. The rejected `--full` key reads were corrected without changing the pair.

Post-close evidence capture: copied `work/note.md`, `work/note.research.sqlite`, and all captured CLI outputs and the changeset into `evidence/base/` without changing their contents; verified byte equality. Saved the user-facing response in `evidence/base-response.md`. Removed the generated temporary workpad and its path pointer after successful capture. No subsequent task was attempted.
